package shopping.cart.api.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import shopping.cart.api.model.User;
import shopping.cart.api.service.UserService;



@RestController
@RequestMapping(value = "/user")
public class UserController {

	@Autowired
	private UserService userService;
	
	

	@PostMapping("/login/{email}")
	public ResponseEntity<User> login(@PathVariable("email") String email) {

		try {
			User user = userService.findOne(email);
			return new ResponseEntity<User>(user, HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<User>(HttpStatus.UNAUTHORIZED);
		}
	}


	@GetMapping("/profile/{email}")
	public ResponseEntity<User> getProfile(@PathVariable("email") String email) {
		User user = userService.findOne(email);
		if (user.getEmail().equals(email)) {
			return ResponseEntity.ok(user);
		} else {
			return ResponseEntity.badRequest().build();
		}

	}

}
