package shopping.cart.api.model;

import javax.persistence.Entity;

@Entity
public class Book extends Product {

	private static final long serialVersionUID = 1L;

	private String gener;
	private String author;
	private String publication;
	
	

	public Book() {
		super();
	}

	/**
	 * @return the gener
	 */
	public String getGener() {
		return gener;
	}

	/**
	 * @param gener the gener to set
	 */
	public void setGener(String gener) {
		this.gener = gener;
	}

	/**
	 * @return the author
	 */
	public String getAuthor() {
		return author;
	}

	/**
	 * @param author the author to set
	 */
	public void setAuthor(String author) {
		this.author = author;
	}

	/**
	 * @return the publication
	 */
	public String getPublication() {
		return publication;
	}

	/**
	 * @param publication the publication to set
	 */
	public void setPublication(String publication) {
		this.publication = publication;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + ((author == null) ? 0 : author.hashCode());
		result = prime * result + ((gener == null) ? 0 : gener.hashCode());
		result = prime * result + ((publication == null) ? 0 : publication.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		Book other = (Book) obj;
		if (author == null) {
			if (other.author != null)
				return false;
		} else if (!author.equals(other.author))
			return false;
		if (gener == null) {
			if (other.gener != null)
				return false;
		} else if (!gener.equals(other.gener))
			return false;
		if (publication == null) {
			if (other.publication != null)
				return false;
		} else if (!publication.equals(other.publication))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Book [gener=" + gener + ", author=" + author + ", publication=" + publication + "]";
	}

	
}
