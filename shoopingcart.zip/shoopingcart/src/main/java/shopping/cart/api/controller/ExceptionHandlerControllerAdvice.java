package shopping.cart.api.controller;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import shopping.cart.api.dto.ErrorResponse;
import shopping.cart.api.exception.InvalidInputException;
import shopping.cart.api.exception.ServiceException;
import shopping.cart.api.exception.UserNotFoundException;

@ControllerAdvice
public class ExceptionHandlerControllerAdvice {
	private static final Logger LOGGER = LoggerFactory.getLogger(ExceptionHandlerControllerAdvice.class);
	@Autowired
	ErrorResponse error;

	@ExceptionHandler
	public ResponseEntity<ErrorResponse> handleException(UserNotFoundException exc, final HttpServletRequest request) {
		LOGGER.error(exc.getMessage(), exc);
		error.setStatus(HttpStatus.NOT_FOUND.value());
		error.setMessage(exc.getMessage());
		error.setRequestedURI(request.getRequestURI());
		return new ResponseEntity<>(error, HttpStatus.NOT_FOUND);
	}

	@ExceptionHandler
	public ResponseEntity<ErrorResponse> handleException(ServiceException exc, final HttpServletRequest request) {
		LOGGER.error(exc.getMessage(), exc);
		error.setStatus(HttpStatus.NOT_FOUND.value());
		error.setRequestedURI(request.getRequestURI());
		error.setMessage(exc.getMessage());
		return new ResponseEntity<>(error, HttpStatus.NOT_FOUND);
	}

	@ExceptionHandler
	public ResponseEntity<ErrorResponse> handleException(HttpRequestMethodNotSupportedException exc,
			final HttpServletRequest request) {
		LOGGER.error(exc.getMessage(), exc);
		error.setStatus(HttpStatus.METHOD_NOT_ALLOWED.value());
		error.setRequestedURI(request.getRequestURI());
		error.setMessage(exc.getMessage());
		return new ResponseEntity<>(error, HttpStatus.METHOD_NOT_ALLOWED);
	}

	@ExceptionHandler
	public ResponseEntity<ErrorResponse> handleException(InvalidInputException exc, final HttpServletRequest request) {
		LOGGER.error(exc.getMessage(), exc);
		error.setStatus(HttpStatus.BAD_REQUEST.value());
		error.setRequestedURI(request.getRequestURI());
		error.setMessage(exc.getMessage());
		return new ResponseEntity<>(error, HttpStatus.BAD_REQUEST);
	}

	@SuppressWarnings("deprecation")
	@ExceptionHandler
	public ResponseEntity<ErrorResponse> handleException(Exception exc, final HttpServletRequest request) {
		LOGGER.error(exc.getMessage(), exc);
		error.setStatus(HttpStatus.METHOD_FAILURE.value());
		error.setRequestedURI(request.getRequestURI());
		error.setMessage(exc.getMessage());
		return new ResponseEntity<>(error, HttpStatus.METHOD_FAILURE);
	}

}
