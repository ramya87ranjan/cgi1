
package shopping.cart.api.service.Impl;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import shopping.cart.api.exception.ProductNotFoundException;
import shopping.cart.api.exception.ServiceException;
import shopping.cart.api.model.Product;
import shopping.cart.api.repository.ProductRepository;
import shopping.cart.api.service.SearchService;

@Service
@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
public class SearchServiceImpl implements SearchService {

	private static final Logger LOGGER = LoggerFactory.getLogger(SearchService.class);
	@Autowired
	private ProductRepository productRepository;

	@Override
	public Product searchProductById(int productId) throws Exception {
		
		try {
			Optional<Product> optionalProduct = productRepository.findById(productId);

			if (optionalProduct.isPresent()) {
				
				return optionalProduct.get();
			}
			throw new ProductNotFoundException("No Product with this ID ");

		} catch (ProductNotFoundException ex) {
			LOGGER.error("No Product with this ID:" + productId);
			throw new ServiceException("No Product with this ID ", ex);
		}

	}

	@Override
	public List<Product> searchProductByname(String name) throws Exception {
		List<Product> products = null;
		try {
			products = productRepository.findAllByProductName(name);

			if (0 == products.size()) {
				throw new ProductNotFoundException("No Product with this name exists:" + name);
			}

			System.out.println(products.size());

		} catch (ProductNotFoundException ex) {
			LOGGER.error("No Product with this name exists:" + name);
			throw new ServiceException(ex);
		}

		return products;
	}

	@Override
	public List<Product> searchProductByCategory(String category) throws Exception {
		List<Product> products = null;
		try {
			products = productRepository.findproductsByCategoryJPQL(category);
			//Using Spring data JPA native query with named parameters
			// productRepository.findproductsByCategoryy(category);

			if (0 == products.size()) {

				throw new ProductNotFoundException("No Product Found with category:" + category);
			}


		} catch (ProductNotFoundException ex) {
			LOGGER.error("Error in SerchbyCategory:No Product Found with Category" + category);
			throw new ServiceException("No Product Found with Category:", ex);
		}

		return products;
	}

}
