package shopping.cart.api.exception;

public class UserNotFoundException extends Exception {
	private static final long serialVersionUID = 1L;

	public UserNotFoundException(String msg) {
		super(msg);
	}

	public UserNotFoundException() {
		super();
	}

	public UserNotFoundException(String msg, Throwable ex) {
		super(msg, ex);
	}

	public UserNotFoundException(Throwable ex) {
		super(ex);
	}

}
