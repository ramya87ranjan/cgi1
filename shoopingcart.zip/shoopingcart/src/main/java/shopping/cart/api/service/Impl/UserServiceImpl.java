package shopping.cart.api.service.Impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import shopping.cart.api.model.User;
import shopping.cart.api.repository.UserRepository;
import shopping.cart.api.service.UserService;


@Service
@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
public class UserServiceImpl implements UserService {

	@Autowired
	private UserRepository userRespository;

	@Override
	public User findOne(String email) {
		return userRespository.findByEmail(email);
	}



}
