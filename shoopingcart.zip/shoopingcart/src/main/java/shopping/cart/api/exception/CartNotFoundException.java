package shopping.cart.api.exception;

public class CartNotFoundException extends ServiceException {

	
	private static final long serialVersionUID = 1L;

	public CartNotFoundException() {
		super();

	}

	public CartNotFoundException(String msg, Throwable cause) {
		super(msg, cause);

	}

	public CartNotFoundException(String msg) {
		super(msg);
	}

	public CartNotFoundException(Throwable cause) {
		super(cause);

	}

}
