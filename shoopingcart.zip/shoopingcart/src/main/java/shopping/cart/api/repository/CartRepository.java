package shopping.cart.api.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import shopping.cart.api.model.Cart;

public interface CartRepository extends JpaRepository<Cart,Integer> {

}
