package shopping.cart.api.service.Impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import shopping.cart.api.dto.ProdcutRequest;
import shopping.cart.api.exception.CartNotFoundException;
import shopping.cart.api.exception.ProductNotFoundException;
import shopping.cart.api.exception.ServiceException;
import shopping.cart.api.model.Cart;
import shopping.cart.api.model.Product;
import shopping.cart.api.repository.CartRepository;
import shopping.cart.api.service.CartService;
import shopping.cart.api.service.SearchService;

@Service
@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
public class CartServiceImpl implements CartService {

	@Autowired
	CartRepository cartRepository;
	@Autowired
	Cart cart;
	@Autowired
	SearchService searchService;

	private static final Logger LOGGER = LoggerFactory.getLogger(CartServiceImpl.class);

	public Map<String, Object> showCart(int cartId) throws Exception {
		Cart cart = cartProducts(cartId);
		List<Product> products = cart.getCartproducts();

		Map<String, Object> message = new HashMap<String, Object>();

		Float totalprice = 0f;
		for (Product p : products) {
			totalprice = totalprice + (p.getPrice() * p.getProductQuantiy());
		}

		message.put("List of Items", products);
		message.put("Total price of cart", totalprice);
		message.put("Total items in a cart", products.size());

		return message;

	}

	public Cart addProductToCart(int productid, int cartId) throws Exception {

		cart = cartProducts(cartId);

		// Checking existing quantity
		Product p = searchService.searchProductById(productid);
		int quantity = p.getProductQuantiy();
		List<Product> products = cart.getCartproducts();
		System.out.println("Size is :" + products.size());
		if (products.size() == 0 || products.contains(p) == false) {
			LOGGER.info("Car is empty or Product does not exist in cart,Increase quantity");
			p.setProductQuantiy(1);
			products.add(p);
			p.setCart(cart);

		} else {

			LOGGER.info("Product exists in cart,Increase quantity");
			products.get(products.indexOf(p)).setProductQuantiy(quantity + 1);
		}
		return cartRepository.save(cart);
	}

	public ResponseEntity<Cart> removeAllProducts(int cartId) throws Exception {
		cart = cartProducts(cartId);

		List<Product> products = cart.getCartproducts();

		products.forEach(p -> {
			p.setCart(null);
			p.setProductQuantiy(0);
		});

		cart.setCartproducts(null);
		cartRepository.delete(cart);

		return new ResponseEntity<>(cart, HttpStatus.OK);

	}

	public ResponseEntity<Cart> removeProduct(int cartId, int productId) throws Exception {

		cart = cartProducts(cartId);
		Product product = searchService.searchProductById(productId);

		List<Product> products = cart.getCartproducts();
		if (products.contains(product)) {
			products.get(products.indexOf(product)).setCart(null);
			products.get(products.indexOf(product)).setProductQuantiy(0);
			products.remove(product);
		} else {
			LOGGER.error("Product exists in cart,Increase quantity");
			throw new ProductNotFoundException("Product is not Present in Cart:Cant Remove");
		}

		cartRepository.save(cart);
		return new ResponseEntity<>(cart, HttpStatus.OK);

	}

	public ResponseEntity<Product> updateProductQuanity(ProdcutRequest prodcutRequest) throws Exception {

		cart = cartProducts(prodcutRequest.getCartId());
		Product product = searchService.searchProductById(prodcutRequest.getProducttId());

		List<Product> products = cart.getCartproducts();
		if (products.contains(product)) {
			if (prodcutRequest.getProductQuantiy() == 0) {
				products.get(products.indexOf(product)).setCart(null);
				products.get(products.indexOf(product)).setProductQuantiy(0);
				products.remove(product);

			} else {
				products.get(products.indexOf(product)).setProductQuantiy(prodcutRequest.getProductQuantiy());
			}

		}

		cartRepository.save(cart);
		return new ResponseEntity<>(product, HttpStatus.OK);

	}

	private Cart cartProducts(int cartId) throws ServiceException {
		try {
			Optional<Cart> optionalCart = cartRepository.findById(cartId);
			if (optionalCart.isPresent()) {
				cart = optionalCart.get();
				return cart;
			}
			throw new CartNotFoundException("No Cart with this ID: " + cartId);
		} catch (CartNotFoundException ex) {
			throw new ServiceException(ex);
		}
	}

}
