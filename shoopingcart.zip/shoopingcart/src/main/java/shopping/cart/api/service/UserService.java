package shopping.cart.api.service;

import shopping.cart.api.model.User;


public interface UserService {

	User findOne(String email);

}
