package shopping.cart.api.controller;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import shopping.cart.api.dto.ProdcutRequest;
import shopping.cart.api.exception.InvalidInputException;
import shopping.cart.api.model.Cart;
import shopping.cart.api.model.Product;
import shopping.cart.api.service.CartService;



/**
 * We have used Controller Advice for Exception handling and logging
 *
 */
@RestController
@RequestMapping("/api/cart")
public class CartController {

	private static final Logger LOGGER = LoggerFactory.getLogger(CartController.class);
	@Autowired
	CartService cartService;

	@RequestMapping(value = "/showCart/{cartId}", method = RequestMethod.GET)
	public ResponseEntity<Map<String, Object>> showCart(@PathVariable("cartId") int cartId) throws Exception {
		LOGGER.info("Dispaly cart contents:");
		return new ResponseEntity<Map<String, Object>>(cartService.showCart(cartId), HttpStatus.OK);

	}

	@RequestMapping(value = "/addProduct", method = RequestMethod.POST)
	public ResponseEntity<Cart> addProductToCart(@RequestBody ProdcutRequest prodcutRequest) throws Exception {

		LOGGER.info("Adding Product To CART");
		Cart cart = cartService.addProductToCart(prodcutRequest.getProducttId(), prodcutRequest.getCartId());
		return new ResponseEntity<>(cart, HttpStatus.OK);

	}

	@RequestMapping(value = "/removeAllProducts/{cartId}", method = RequestMethod.DELETE)
	public ResponseEntity<Cart> RemoveAllProducts(@PathVariable("cartId") int cartId) throws Exception {
		LOGGER.info("Removing the Products and deleting the Cart with Id:" + cartId);
		return cartService.removeAllProducts(cartId);

	}

	@RequestMapping(value = "/removeAProduct", method = RequestMethod.DELETE)
	public ResponseEntity<Cart> removeAProduct(@RequestBody ProdcutRequest prodcutRequest) throws Exception {
		LOGGER.info("Removing Product From Cart");
		int productId = prodcutRequest.getProducttId();
		int cartId = prodcutRequest.getCartId();
		return cartService.removeProduct(cartId, productId);

	}

	@RequestMapping(value = "/updateProduct", method = RequestMethod.PUT)
	public ResponseEntity<Product> updateProductQuantity(@RequestBody ProdcutRequest prodcutRequest) throws Exception {
		LOGGER.info("Update  Product Quantity  in Cart");
		if (prodcutRequest.getProductQuantiy() < 0) {
			LOGGER.error("Quantity must be  +ve");
			throw new InvalidInputException("Quantity Can not be -ve");
		}
		return cartService.updateProductQuanity(prodcutRequest);
	}

}
