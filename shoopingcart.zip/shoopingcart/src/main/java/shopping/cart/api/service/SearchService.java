package shopping.cart.api.service;

import java.util.List;

import shopping.cart.api.model.Product;

public interface SearchService {

	public Product searchProductById(int id) throws Exception;

	public List<Product> searchProductByname(String name) throws Exception;

	public List<Product> searchProductByCategory(String category) throws Exception;

}
