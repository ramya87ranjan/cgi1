package shopping.cart.api.exception;

public class EmptyCartException extends ServiceException {

	private static final long serialVersionUID = 1L;

	public EmptyCartException() {
		super();
	}

	public EmptyCartException(String message) {
		super();
	}

	public EmptyCartException(String message, Throwable cause) {
		super(message, cause);
	}

	public EmptyCartException(Throwable cause) {
		super(cause);
	}

}
