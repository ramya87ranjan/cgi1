package shopping.cart.api.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import shopping.cart.api.model.Product;

public interface ProductRepository extends JpaRepository<Product, Integer> {

	/*
	 * //Using Spring Data finder method to find products by Category 
	 * List<Product> findAllByCategory(String category); 
	 */

	
	/*
	 * //Using native query with named parameters
	 * @Query(value = "SELECT * FROM products  WHERE category = ?1", nativeQuery =
	 * true)
	 *	  List<Product> findproductsByCategory(String category);
	 */

	@Query(value = "FROM Product  WHERE catagory = :category")
	List<Product> findproductsByCategoryJPQL(@Param("category") String category);// using JPQL

	List<Product> findAllByProductName(String productName);// using finderMethods

	@Query(value = "SELECT * FROM products  WHERE cart_id = ?1 and id=?2", nativeQuery = true)
	List<Product> findproductinCart(int cartid, int id);//Using native query with named parameters

}
