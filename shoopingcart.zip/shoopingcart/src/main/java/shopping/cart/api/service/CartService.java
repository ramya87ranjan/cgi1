package shopping.cart.api.service;

import java.util.Map;

import org.springframework.http.ResponseEntity;

import shopping.cart.api.dto.ProdcutRequest;
import shopping.cart.api.model.Cart;
import shopping.cart.api.model.Product;

public interface CartService {

	public Map<String, Object> showCart(int id) throws Exception;

	public Cart addProductToCart(int productid, int cartId) throws Exception;

	public ResponseEntity<Cart> removeAllProducts(int cartId) throws Exception;

	public ResponseEntity<Cart> removeProduct(int cartId, int productId) throws Exception;

	public ResponseEntity<Product> updateProductQuanity(ProdcutRequest updateProdcut) throws Exception;

}
