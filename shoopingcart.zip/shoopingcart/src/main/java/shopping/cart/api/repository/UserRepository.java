package shopping.cart.api.repository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import shopping.cart.api.model.User;

/**
 * @author M1054539
 *
 */
@Repository
public interface UserRepository extends CrudRepository<User, Long> {

	@Query("SELECT u FROM User u where u.email = ?1")
	User findByEmail(String email);

}
